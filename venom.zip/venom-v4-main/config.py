# Don't use quotes( " and ' )
#SCRIPT BY VENOMxCRAZY
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("7259034553:AAHYWdbEpMxeJAkv_HH1QYOChdMLMvot13E")

  #Enter Your telegram username here without @
OWNER_USERNAME=("venomXcrazy")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("5588464519")







  
